package minhal.tomerbu.edu.recyclerdemo.ThirdTask;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import minhal.tomerbu.edu.recyclerdemo.R;

public class ThirdActivity extends AppCompatActivity {

    private final static int RC_CALL = 1;
    private final static int RC_MAP = 2;
    private final static int RC_EMAIL = 3;
    Button mapsbtn, callerbtn, emailbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mapsbtn = findViewById(R.id.mapbtn);
        callerbtn = findViewById(R.id.callerbtn);
        emailbtn = findViewById(R.id.emailbtn);

        mapsbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMap();
            }
        });
        callerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                call();
            }
        });
        emailbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                composeEmail(new String[]{"nomail@nomail.com"}, "nothing");
            }
        });

    }

    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == RC_MAP && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showMap();
        }

        if (requestCode == RC_CALL && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            call();
        }
        if (requestCode == RC_EMAIL && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            composeEmail(new String[]{"nomail@nomail.com"}, "nothing");
        }
    }


    private void call() {
        Uri uri = Uri.parse("tel:050712312");
        Intent intent = new Intent(Intent.ACTION_CALL, uri);

        //if no permission? Return away from this method , but first we ask for permission.
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, RC_CALL);
            return;
        }
        startActivity(intent);
    }

    public void showMap() {

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:47.6,-122.3"));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


}
