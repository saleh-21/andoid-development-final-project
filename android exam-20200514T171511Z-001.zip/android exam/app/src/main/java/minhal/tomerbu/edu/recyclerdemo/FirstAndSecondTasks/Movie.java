package minhal.tomerbu.edu.recyclerdemo.FirstAndSecondTasks;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Model class for Movie (json example).
 */
public class Movie {
    private final String title;
    private final String image;
    private double rating;
    private final int releaseYear;
    private ArrayList<String> genres = new ArrayList<>();
    private int genresNum;
    private String overview;

    //constructor:
    public Movie(String title, String image, int releaseYear, double rating ,String overview , String... genre) {
        this.title = title;
        this.image = image;
        this.rating = rating;
        this.releaseYear = releaseYear;
        this.overview=overview;

        //for each item in the var args...
        //append the genre to the list

        if (genre != null)
            genresNum=genre.length;
            Collections.addAll(genres, genre);
    }

    //toString, Getters and Setters
    @Override
    public String toString() {
        return "Movie{" +
                "title='" + title + '\'' +
                ", image='" + image + '\'' +
                ", rating=" + rating +
                ", releaseYear=" + releaseYear +
                ", genres=" + genres +
                '}';
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public double getRating() {
        return rating;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getGenres() {
        if (genres != null) {
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < genres.size(); i++) {
                stringBuilder.append(genres.get(i));
                if (i < genresNum - 1) {
                    stringBuilder.append(",");
                }
            }
            return stringBuilder.toString();
        }else{
            return "";
        }
    }

    public String getOverview(){return overview;}
}
