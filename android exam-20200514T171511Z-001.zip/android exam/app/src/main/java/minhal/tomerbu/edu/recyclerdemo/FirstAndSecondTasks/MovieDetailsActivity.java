package minhal.tomerbu.edu.recyclerdemo.FirstAndSecondTasks;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import minhal.tomerbu.edu.recyclerdemo.R;

public class MovieDetailsActivity extends AppCompatActivity {

    TextView tvTitle,tvPopularity, tvOverview;
    ImageView movieImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        updateUI(null);
    }

    private void updateUI(Movie movie) {

    }
}
