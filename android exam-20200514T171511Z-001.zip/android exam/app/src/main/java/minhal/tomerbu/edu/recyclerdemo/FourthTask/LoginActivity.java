package minhal.tomerbu.edu.recyclerdemo.FourthTask;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import minhal.tomerbu.edu.recyclerdemo.R;

public class LoginActivity extends AppCompatActivity {
    TextView textView;
    Button btn;
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textView =findViewById(R.id.textView);
        btn = findViewById(R.id.btn);
        editText = findViewById(R.id.editText);


        final SharedPreferences sharedPreferences = getSharedPreferences("user", MODE_PRIVATE);

        if(sharedPreferences.getBoolean("firstLogin",true)) {
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("userName", String.valueOf(editText.getText()));
                    editor.putBoolean("firstLogin", false);
                    editor.apply();
                    updateUI();

                }
            });
        }
        else{
            updateUI();
        }
    }

    private void updateUI() {
         SharedPreferences sharedPreferences = getSharedPreferences("user", MODE_PRIVATE);
        String name= sharedPreferences.getString("userName","");
        textView.setText("Welcome, "+name);
        btn.setVisibility(View.GONE);
        editText.setVisibility(View.GONE);
    }


}
